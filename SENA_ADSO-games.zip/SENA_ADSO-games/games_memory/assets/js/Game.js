
class Game {

  constructor(contGame, level, prog, chor, speed, maxMilliseconds) {
    // Se asignan los elementos del DOM a variables de la clase
    this.progCont = document.getElementById(prog);
    this.contGame = document.getElementById(contGame);
    this.contCardGame = document.querySelectorAll(".contCard");
    // Se obtienen rutas y otros datos necesarios para el juego
    this.getServer = window.location.origin; //server path name
    this.folderPath = "/games_memory"; //name folder 
    this.serverPath = this.getServer + this.folderPath; //server path name
    this.uriJson = "https://api-rest-9541a-default-rtdb.firebaseio.com/api/users.json"; // path data JSON
    this.pathImg = this.folderPath + "/assets/img/memory/"; // path data imgs 
    this.pathImgDafault = this.serverPath + "/assets/img/memory/img_default.jpg";
    this.longBootstrap = 12 / level;
    this.newArrayGames = [];
    this.arrayGamesCard = [];
    this.getDataJson();
    this.num = level;
    this.max = 19;
    this.min = 0;
    this.maxCard = (this.num * this.num) / 2;
    this.selected = true;
    this.selectedCard = [];
    this.totalPointGame = 0;
    this.totalPoint = 0;
    this.contCardClass = "contCard"; // Esta es la clase contenedora de las tarjetas
    this.objChronometer = new Chronometer(chor, speed, maxMilliseconds);
    this.timeOut=2500;
    this.storageGame = new StorageGame('users');
  }

  
  getDataJson() {
    // Se realiza una solicitud para obtener datos JSON del servidor
    fetch(this.uriJson)
      .then(response => response.json())
      .then(data => {
        // Se establecen los elementos del juego una vez que se reciben los datos
        this.setElements(data);
        this.objChronometer.startChronometer();
      });
  }

  
  getRandomArray(min, max, count) {
    // Se genera un array aleatorio de elementos dentro de un rango específico
    let contentGame = [];
    let contentNum = [];
    if (min > max || count > max - min) {
      return false;
    }
    while (contentGame.length < count) {
      var num = Math.floor((Math.random() * (max - min)) + min);
      if (!contentNum.includes(num)) {
        contentGame.push(this.newArrayGames[num]);
        contentNum.push(num);
      }
    }
    this.arrayGamesCard = contentGame.concat(contentGame);
    return this.setShuffleArray(this.arrayGamesCard);
  }

  
  setShuffleArray(dataArrar) {
    // Se baraja el array aleatorio
    return dataArrar.sort(() => Math.random() - 0.5);
  }

  
  setElements(arraJson) {
    // Se establecen los elementos del juego en el DOM
    let cards = "";
    let cardsAux = "";
    let cont = 0;
    let row = this.num - 1;
    this.contGame.innerHTML = "";
    this.newArrayGames = arraJson;
    const getNewArray = this.getRandomArray(this.min, this.max, this.maxCard);

    for (let i = 0; i < getNewArray.length; i++) {
      this.totalPointGame += getNewArray[i].valor;
      // Se generan las tarjetas del juego
      cardsAux += '<div class="col-' + this.longBootstrap + ' pt-2 mx-auto ' + this.contCardClass + '"><div class="card" ><img data-value="' + getNewArray[i].valor + '" data-src="'+this.pathImg+getNewArray[i].img + '" src="'+this.pathImgDafault+'" class="card-img-top" alt="..."> <div class="card-body"><h5 class="card-title">' + getNewArray[i].nombre + '</h5><p class="card-text">' + getNewArray[i].valor + '</p></div></div></div>';
      cont++;
      if (row == cont - 1) {
        cards += '<div class="row">' + cardsAux + '</div>';
        cont = 0;
        cardsAux = "";
      }
    }
    this.contGame.innerHTML = cards;
    this.changeElementImg();
  }

  
  changeElementImg() {
    // Se cambian las imágenes al hacer clic en las tarjetas
    this.contCardGame = document.querySelectorAll('.' + this.contCardClass);
    var pathDefault = this.getServer + this.pathImgDafault;
    for (let i = 0; i < this.contCardGame.length; i++) {
      const objImg = this.contCardGame[i].querySelector('img');
      this.contCardGame[i].addEventListener('click', () => {
        if (objImg.src.includes(this.pathImgDafault)) {
          // Agregar la clase que aplica la animación de rotación
          objImg.classList.add('rotate-animation');
          setTimeout(() => {
            objImg.src = objImg.dataset.src;
            this.setSelectCard(objImg);
            // Remover la clase después de que la animación termine (aprox. 1 segundo)
            setTimeout(() => {
              objImg.classList.remove('rotate-animation');
            }, 1000);
          }, 500);
        }
      });
    }
  }
  
  
  
  setSelectCard(obj) {
    // Se seleccionan las tarjetas y se comparan para ver si coinciden
    let selectedPoint = 0;
    if (this.selected) {
      this.selected = false;
      this.selectedCard[0] = obj;
    } else {
      this.selectedCard[1] = obj;
      this.selected = true;
    }
    if (this.selectedCard.length > 1) { 
      if (this.selectedCard[0].dataset.src == this.selectedCard[1].dataset.src) {
        this.selectedCard[0].parentElement.removeEventListener('click', () => {});
        this.selectedCard[1].parentElement.removeEventListener('click', () => {});
        selectedPoint = this.selectedCard[0].dataset.value;
        this.selectedCard = [];
        this.totalPoint += parseInt(selectedPoint);
        this.setProgressData(((this.totalPoint) / (this.totalPointGame / 2)) * 100);
        this.updatePointsCounter(); // Llama a la función para actualizar el contador de puntos        
      } else {
        setTimeout(() => {
        this.selectedCard[0].src = this.pathImgDafault;
        this.selectedCard[1].src = this.pathImgDafault;
        this.selectedCard = [];
        this.updateAttemptsCounter(); // Llama a la función para actualizar el contador de intentos


        }, 1000);
      }
    }
  }

  
updatePointsCounter() {
  // Actualiza el contador de puntos en la interfaz HTML
  const pointsCounterElement = document.getElementById('labelPoints'); 
  if (pointsCounterElement) {
    pointsCounterElement.textContent = 'PUNTOS: ' + this.totalPoint;
  
    // Almacena los puntos en el localStorage con la clave 'points'
    localStorage.setItem('points', this.totalPoint);
  }
}


  updateAttemptsCounter() {
    // Actualiza el contador de intentos en la interfaz HTML
    const attemptsCounterElement = document.getElementById('labelIntentos'); // Suponiendo que tu elemento tiene el ID 'labelIntentos'
    if (attemptsCounterElement) {
      let currentAttempts = parseInt(attemptsCounterElement.textContent.split(': ')[1]);
      if (currentAttempts > 0) {
        currentAttempts--;
        attemptsCounterElement.textContent = 'INTENTOS: ' + currentAttempts;
      }
      if (currentAttempts === 0) {
        this.showGameOverMessage();
      }
    }
  }
  
  showGameOverMessage() {
    // Muestra el modal de juego perdido
    const gameOverModal = new bootstrap.Modal(document.getElementById('gameOverModal'));
    gameOverModal.show();
  
    // Asigna la función de reiniciar juego al botón dentro del modal
    const restartGameBtn = document.getElementById('restartGameBtn');
    restartGameBtn.addEventListener('click', () => {
      this.restartGame();
      gameOverModal.hide();
    });
  }

  restartGame() {
    // Reiniciar el juego restableciendo todos los valores y elementos necesarios
    this.totalPoint = 0;
    this.totalAttempts = 3; 
    document.getElementById('labelPoints').textContent = 'PUNTOS: 0';
    document.getElementById('labelIntentos').textContent = 'INTENTOS: ' + this.totalAttempts;
    this.objChronometer.clearChronometer();
  }

  //This method is for set progress data 
  setProgressData(dataProgress) {
    this.progCont.innerText = parseInt(dataProgress) + "%";
    this.progCont.style.width = dataProgress + "%";

    if (dataProgress == 100) {
      this.objChronometer.stopChoronometer();
      const gameWonModal = new bootstrap.Modal(document.getElementById('gameWonModal'));
      gameWonModal.show(); 
      let currentUser = {
        username: "", // Cambia esto por el nombre del usuario actual
        points: this.totalPoint
      }
      // Actualizar la tabla de historial de puntos
      createTableUser();

  }
}
  
}